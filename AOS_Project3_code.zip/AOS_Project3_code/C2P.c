//Implemented by Rishabh Choudhary
#include        <stdio.h>
#include        <rpc/rpc.h> 
#include        "C2S.h"
#include	<stdlib.h>
#include	<string.h>
#include	"ClientServer.h"
#include	"ClientAppServer.h"

char * display(char * Message)
{
	char * DisplayBuffer;
	DisplayBuffer=(char*)malloc(1050*sizeof(char));
	memset(DisplayBuffer,'\0',1050);
        sprintf(DisplayBuffer,"%-20s:%-50s\n","Client",Message);
	printf(DisplayBuffer);
	return DisplayBuffer;
}

void prompt(char * Message,char * Input)
{
	display(Message);
	printf("%-20s:\t","Client");
	scanf("%s",Input);
}

int createAppServerConn(CLIENT ** ClientConn,char * Server)
{
	 if ((*ClientConn = clnt_create(Server, SP_PROG, SP_VERS, "udp"))==NULL)
        {
                clnt_pcreateerror(constructMessage("%-20s","Client"));
                return errorMessage("Cannot create connection");
        }
	display("Connection created");
	return 0;
}

int appRequestBuilder(RequestStruct * Request,char * C,char * ArgumentStr,ReqTokenStruct Token)
{
	if(copyText(Request->Content.C,SIZE,C,strlen(C))) return errorMessage("Cannot copy C to request");
	if(copyText(Request->Content.Argument.String,ARGSIZE,ArgumentStr,strlen(ArgumentStr))) return errorMessage("Cannot copy Argument to request");
	Request->Content.Argument.Length=strlen(addEndOfString(Request->Content.Argument.String,ARGSIZE));
	Request->Content.Token=Token;
	Request->Length=strlen(addEndOfString(Request->Content.C,SIZE))+Request->Content.Argument.Length+strlen(addEndOfString(Request->Content.Token.C,SIZE))+strlen(addEndOfString(Request->Content.Token.S,SIZE))+strlen(addEndOfString(Request->Content.Token.Key,SIZE));
	return 0;
}

int findAlphabet(CLIENT * ClientAppServerConn,char * C,ReqTokenStruct Token)
{
        struct ReplyStruct * Reply;
        struct RequestStruct Request;
	char ArgumentStr[ARGSIZE];
	prompt("Enter String to find Alphabets",ArgumentStr);
	if(appRequestBuilder(&Request,C,ArgumentStr,Token)) return errorMessage("Cannot create request");
	printRequest(Request);
	if((Reply=alpha_1(Request,ClientAppServerConn))==NULL)
        {
                clnt_perror(ClientAppServerConn, constructMessage("%-20s","Client"));
                return errorMessage("Call failed");
        }
        display("Reply Received");
        printReply(*Reply);
       	if(Reply->Length==-1) return errorMessage("Bad reply");
        return 0;
}

int findNumeric(CLIENT * ClientAppServerConn,char * C,ReqTokenStruct Token)
{
        struct ReplyStruct * Reply;
        struct RequestStruct Request;
        char ArgumentStr[ARGSIZE];
        prompt("Enter String to find Numbers",ArgumentStr);
       	if(appRequestBuilder(&Request,C,ArgumentStr,Token)) return errorMessage("Cannot create request");
	printRequest(Request);
        if((Reply=numeric_1(Request,ClientAppServerConn))==NULL)
        {
                clnt_perror(ClientAppServerConn, constructMessage("%-20s","Client"));
                return errorMessage("Call failed");
        }
        display("Reply Received");
        printReply(*Reply);
       	if(Reply->Length==-1) return errorMessage("Bad reply");
        return 0;
}

int main(int argc,char * argv[])
{
	CLIENT *ClientAppServerConn;
	ReqTokenStruct Token;
	strcpy(Token.C,"mitali");
	strcpy(Token.S,"rishabh");
	strcpy(Token.Key,"abcdefgh");
	if(createAppServerConn(&ClientAppServerConn,argv[3])) return errorMessage("Connection failed");	
	if(findAlphabet(ClientAppServerConn,argv[1],Token)) return errorMessage("Not able to find alphabets");
	if(findNumeric(ClientAppServerConn,argv[1],Token)) return errorMessage("Not able to find numbers");
        clnt_destroy(ClientAppServerConn);
	return 0;
	 
}
