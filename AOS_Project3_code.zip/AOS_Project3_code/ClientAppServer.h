#define		ARGSIZE 100
#define		ENCMSGSIZE 1000

void printReqToken(ReqTokenStruct Token)
{
        display(constructMessage("Token.C:%s",addEndOfString(Token.C,SIZE)));
        display(constructMessage("Token.S:%s",addEndOfString(Token.S,SIZE)));
        printEncrypted("Token.KCS:",Token.Key,SIZE);
}	

void printArgument(MsgStruct Argument)
{
        display(constructIntMessage("Argument.Length:%d",Argument.Length));
        display(constructMessage("Argument.String:%s",Argument.String));
}

void printRequest(RequestStruct Request)
{
        display("-----------Request-----------");
        display(constructIntMessage("Length:%d",Request.Length));
        display(constructMessage("C:%s",addEndOfString(Request.Content.C,SIZE)));
        printEncrypted("Encrypted Argument",Request.Content.Argument.Message,Request.Content.Argument.Length);
        printEncrypted("Encrypted Token",Request.Content.Token.Message,Request.Content.Token.Length);
        display("-----------------------------");
}

void printReply(ReplyStruct Reply)
{
        display("------------Reply------------");
        display(constructIntMessage("Length:%d",Reply.Length));
        display(constructMessage("C:%s",addEndOfString(Reply.Content.C,SIZE)));
        display(constructMessage("S:%s",Reply.Content.S));
        display(constructIntMessage("Output.Length:%d",Reply.Content.Output.Length));
        display(constructMessage("Output.String:%s",Reply.Content.Output.String));
        display("-----------------------------");
}

