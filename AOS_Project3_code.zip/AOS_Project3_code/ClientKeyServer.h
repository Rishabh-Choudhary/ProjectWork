void printToken(KeyTokenStruct Token)
{
        display(constructMessage("Token.C:%s",addEndOfString(Token.C,SIZE)));
        display(constructMessage("Token.S:%s",addEndOfString(Token.S,SIZE)));
        printEncrypted("Token.KCS:",Token.Key,SIZE);
}	

void printKeyRequest(KeyRequestStruct KeyReq)
{
        display("------------Request----------");
        display(constructIntMessage("Length:%d",KeyReq.Length));
        display(constructMessage("C:%s",addEndOfString(KeyReq.Content.C,SIZE)));
        display(constructMessage("S:%s",addEndOfString(KeyReq.Content.S,SIZE)));
        display("-----------------------------");
}

void printKeyReply(KeyReplyStruct Reply)
{
        display("------------Reply------------");
        display(constructIntMessage("Length:%d",Reply.Length));
        display(constructMessage("C:%s",addEndOfString(Reply.Content.C,SIZE)));
        display(constructMessage("S:%s",addEndOfString(Reply.Content.S,SIZE)));
        printEncrypted("KCS:",Reply.Content.Key,SIZE);
        printEncrypted("Encrypted Token",Reply.Content.Token.Message,Reply.Content.Token.Length);
        display("-----------------------------");
}

