//Implemented by Rishabh Choudhary
#include        <stdio.h>
#include        <rpc/rpc.h> 
#include	<stdlib.h>
#include	<string.h>
#include        "C1K.h"
#include        "C2S.h"
#include	"ClientServer.h"
#include	"ClientKeyServer.h"
#include	"ClientAppServer.h"
#include	"Ckey.h"
#include	"global.h"
#include	"rsaref.h"

void display(char * Message)
{
        printf("%-20s:%-50s\n","Client",Message);
}

int createKeyServerConn(CLIENT ** ClientConn,char * Server)
{
	 if ((*ClientConn = clnt_create(Server, CK_PROG, CK_VERS, "udp"))
 == NULL)
        {
                clnt_pcreateerror(constructMessage("%-20s","Client"));
                return errorMessage("Cannot create connection");
        }
        display(constructMessage("Connection created with Key server %s",Server));
	return 0;
}

int keyRequestBuilder(KeyRequestStruct * KeyRequest,char * C,char * S)
{
	if(copyText(KeyRequest->Content.C,SIZE,C,strlen(C)))
return errorMessage("Cannot copy C to request");
        if(copyText(KeyRequest->Content.S,SIZE,S,strlen(S)))
return errorMessage("Cannot copy S to request");
        KeyRequest->Length=strlen(addEndOfString(KeyRequest->Content.C,SIZE))+strlen(addEndOfString(KeyRequest->Content.S,SIZE));
        display("Request created");
        printKeyRequest(*KeyRequest);
	return 0;
}

int decryptEncKeyReply(EncKeyReplyStruct EncKeyReply,KeyReplyStruct * KeyReply)
{
	unsigned int DecKeyReplyLength=0;
	unsigned char DecKeyReplyString[ENCTOKENSIZE];
	unsigned char InitVector[8];
	memset(InitVector, '\0', 8);
	printEncrypted("Encrypted Key Reply",EncKeyReply.Message,EncKeyReply.Length);
	display(constructMessage("Decrypting Key Reply with key %s",addEndOfString(key,SIZE))); 
	R_DecryptPEMBlock(DecKeyReplyString, &DecKeyReplyLength, EncKeyReply.Message,EncKeyReply.Length,key,InitVector);
	if(DecKeyReplyLength==0) return errorMessage("Cannot decrypt Key Reply");
	memcpy((unsigned char*) KeyReply,DecKeyReplyString,DecKeyReplyLength);
	display("Reply decrypted");
	printKeyReply(*KeyReply);
	return 0;
}	
	
int getKey(CLIENT * ClientKeyServerConn,char * C, char * S, KeyReplyStruct * KeyReply)
{
        KeyRequestStruct KeyRequest;
	EncKeyReplyStruct * EncKeyReply;
	if(keyRequestBuilder(&KeyRequest,C,S)) return errorMessage("Cannot create request");
	display("Sending request to Key Server");
        if((EncKeyReply=reqskey_1(KeyRequest,ClientKeyServerConn))==NULL)
        {
                clnt_perror(ClientKeyServerConn, constructMessage("%-20s","Client"));
                return errorMessage("Call failed");
        }
        display("Reply Received");
	if(EncKeyReply->Length==-1) return errorMessage("Bad reply");
	if(decryptEncKeyReply(*EncKeyReply,KeyReply)) return errorMessage("Cannot read Reply");
	return 0;	
}

void prompt(char * Message,char * Input)
{
	display(Message);
	printf("%-20s:\t","Client");
	scanf("%s",Input);
}

int createAppServerConn(CLIENT ** ClientConn,char * Server)
{
	 if ((*ClientConn = clnt_create(Server, SP_PROG, SP_VERS, "udp"))
 == NULL)
        {
                clnt_pcreateerror(constructMessage("%-20s","Client"));
                return errorMessage("Cannot create connection");
        }
	display(constructMessage("Connection created with App server %s",Server));
	return 0;
}

int encryptArgument(EncMsgStruct * EncArgument,char *ArgumentStr, char *KCS)
{
	MsgStruct Argument;
	unsigned InitVector[8];
	memset(InitVector,'\0',8);
	if(copyText(Argument.String,ARGSIZE,ArgumentStr,strlen(ArgumentStr))) return errorMessage("Cannot copy Argument to request");
	Argument.Length=strlen(addEndOfString(Argument.String,ARGSIZE));
	display("Argument built");
	printArgument(Argument);
	display("Encrypting Argument with Session key KCS");
	printEncrypted("Session key KCS",KCS,SIZE); 
	R_EncryptPEMBlock(EncArgument->Message,&(EncArgument->Length),(unsigned char*) &Argument,sizeof(Argument),KCS,InitVector);
	if(EncArgument->Length==0) return errorMessage("Cannot encrypt Argument");
	display("Argument Encrypted");
	return 0;
}	

int appRequestBuilder(RequestStruct * Request,char * C,char * ArgumentStr,EncReqTokenStruct Token,char * KCS)
{
	if(copyText(Request->Content.C,SIZE,C,strlen(C))) return errorMessage("Cannot copy C to request");
	if(encryptArgument(&(Request->Content.Argument),ArgumentStr,KCS)) return errorMessage("Cannot copy encrypted Argument to request");
	Request->Content.Token=Token;
	Request->Length=strlen(addEndOfString(Request->Content.C,SIZE))+Request->Content.Argument.Length+Request->Content.Token.Length;
        display("Request created");
        printRequest(*Request);
	return 0;
}

int decryptEncReply(EncReplyStruct EncReply,ReplyStruct * Reply,char * KCS)
{
	unsigned int DecReplyLength=0;
	unsigned char DecReplyString[ENCMSGSIZE];
	unsigned char InitVector[8];
	memset(InitVector, '\0', 8);
	printEncrypted("Encrypted Reply",EncReply.Message,EncReply.Length);
	display("Decrypting Reply with Session key KCS");
	printEncrypted("Session key KCS",KCS,SIZE);
	R_DecryptPEMBlock(DecReplyString, &DecReplyLength, EncReply.Message,EncReply.Length,KCS,InitVector);
	if(DecReplyLength==0) return errorMessage("Cannot decrypt Reply");
	memcpy((unsigned char*) Reply,DecReplyString,DecReplyLength);
	display("Reply decrypted");
	printReply(*Reply);
	return 0;
}
	
int findAlphabet(CLIENT * ClientAppServerConn,char * C,EncReqTokenStruct Token,char * KCS)
{
        struct EncReplyStruct * EncReply;
        struct ReplyStruct * Reply;
        struct RequestStruct Request;
	char ArgumentStr[ARGSIZE];
	prompt("Enter String to find Alphabets",ArgumentStr);
	if(appRequestBuilder(&Request,C,ArgumentStr,Token,KCS)) return errorMessage("Cannot create request");
	display("Sending request to App Server");	
	if((EncReply=alpha_1(Request,ClientAppServerConn))==NULL)
        {
                clnt_perror(ClientAppServerConn, constructMessage("%-20s","Client"));
                return errorMessage("Call failed");
        }
        display("Reply Received");
       	if(EncReply->Length==-1) return errorMessage("Bad reply");
        if(decryptEncReply(*EncReply,Reply,KCS)) return errorMessage("Cannot read Reply");
	free(EncReply);
	free(Reply);
        return 0;
}

int findNumeric(CLIENT * ClientAppServerConn,char * C,EncReqTokenStruct Token,char * KCS)
{
        struct EncReplyStruct * EncReply;
        struct ReplyStruct * Reply;
        struct RequestStruct Request;
        char ArgumentStr[ARGSIZE];
        prompt("Enter String to find Numbers",ArgumentStr);
       	if(appRequestBuilder(&Request,C,ArgumentStr,Token,KCS)) return errorMessage("Cannot create request");
	display("Sending request to App Server");	
        if((EncReply=numeric_1(Request,ClientAppServerConn))==NULL)
        {
                clnt_perror(ClientAppServerConn, constructMessage("%-20s","Client"));
                return errorMessage("Call failed");
        }
        display("Reply Received");
       	if(EncReply->Length==-1) return errorMessage("Bad reply");
        if(decryptEncReply(*EncReply,Reply,KCS)) return errorMessage("Cannot read Reply");
	free(EncReply);
	free(Reply);
        return 0;
}

int useService(CLIENT * ClientAppServerConn, char * C,EncReqTokenStruct Token,char * KCS)
{
        char Option[3];
        memset(Option,'\0',3);
        display("List of available services");
        display("1. Find alphabets");
        display("2. Find numbers");
        while(atoi(Option)!=1&&atoi(Option)!=2)
        {
                prompt("Choose service",Option);
                if(atoi(Option)!=1&&atoi(Option)!=2)
                        display("Invalid option");
        }
        if(atoi(Option)==1)
                if(findAlphabet(ClientAppServerConn,C,Token,KCS)) return errorMessage("Not able to find alphabets");
        if(atoi(Option)==2)
                if(findNumeric(ClientAppServerConn,C,Token,KCS)) return errorMessage("Not able to find numbers");
        display("Request completed");
        return 0;
}

int copyToken(EncKeyTokenStruct KeyReplyToken,EncReqTokenStruct * Token)
{
	if(copyText(Token->Message,ENCTOKENSIZE,KeyReplyToken.Message,ENCTOKENSIZE)) return errorMessage("Cannot copy token"); 
	Token->Length=KeyReplyToken.Length; 
	return 0;
}

int main(int argc,char * argv[])
{
	system("clear");
	KeyReplyStruct KeyReply;	
	CLIENT *ClientKeyServerConn;
	CLIENT *ClientAppServerConn;
	EncReqTokenStruct Token;
	if(createKeyServerConn(&ClientKeyServerConn,argv[3])) return errorMessage("Connection failed");	
	if(getKey(ClientKeyServerConn,argv[1],argv[2],&KeyReply)) return errorMessage("Cannot get key");	
	clnt_destroy(ClientKeyServerConn);
	if(copyToken(KeyReply.Content.Token,&Token)) return errorMessage("Cannot pick token for App Server request");
	if(createAppServerConn(&ClientAppServerConn,argv[4])) return errorMessage("Connection failed");	
        if(useService(ClientAppServerConn,argv[1],Token,addEndOfString(KeyReply.Content.Key,SIZE))) return errorMessage("Service failed");
	clnt_destroy(ClientAppServerConn);
	return 0;
}
