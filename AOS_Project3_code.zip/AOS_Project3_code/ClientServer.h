#define 	SIZE 8
#define		ENCTOKENSIZE 1000
 
void display(char *);

int errorMessage(char*);

int InitializeMessageString(char ** FormattedString)
{
        *FormattedString=(char*)malloc((1000)*sizeof(char));
        if(*FormattedString==NULL) return errorMessage("Cannot initialize Message String");
        memset(*FormattedString,'\0',1000);
        return 0;
}

char * constructMessage(char * Format,char * String)
{
        char * FormattedString;
        if(InitializeMessageString(&FormattedString)) return NULL;
        sprintf(FormattedString,Format,String);
        return FormattedString;
}

char * constructIntMessage(char * Format,int Value)
{
        char * FormattedString;
        if(InitializeMessageString(&FormattedString)) return NULL;
        sprintf(FormattedString,Format,Value);
        return FormattedString;
}


int errorMessage(char * Error)
{
        display(constructMessage("**Error**\t%s",Error));
        return 1;
}

int copyText(char * field,int fieldlength,char * arg,int arglength)
{
        if(field==NULL||arg==NULL||fieldlength<=0||arglength<0) return errorMessage("Cannot Copy Text");
        memset(field,'\0',fieldlength);
	if(arglength>0)
        	memcpy(field,arg,arglength<fieldlength?arglength:fieldlength);
        return 0;
}

char * addEndOfString(char * String,int length)
{
        char * StringWithEnd=(char*)malloc((length+1)*sizeof(char));
        if(StringWithEnd==NULL) return NULL;
	memset(StringWithEnd,'\0',length+1);
        if(copyText(StringWithEnd,length+1,String,length)) return NULL;
        return StringWithEnd;
}

void printEncrypted(char * EncDataType,char * EncDataString,int EncDataLength)
{
        int i;
        char * EncDataIntString;
	EncDataIntString=(char*)malloc(((EncDataLength*4)+1)*sizeof(char));
        memset(EncDataIntString,'\0',(EncDataLength*4)+1);
        for(i=0;i<EncDataLength;i++)
        {
                char EncDataIntStringPart[4];
                sprintf(EncDataIntStringPart,"%03d ",(int)EncDataString[i]);
                strcat(EncDataIntString,addEndOfString(EncDataIntStringPart,4));
        }
        display(EncDataType);
        display(EncDataIntString);
}
