//Implemented by Rishabh Choudhary
#include        <rpc/rpc.h>     /* standard RPC include file */
#include        "C1K.h"
#include 	<stdio.h>
#include 	<stdlib.h>
#include	<string.h>
#include	"ClientServer.h"
#include	"ClientKeyServer.h"
#include	"global.h"
#include 	"rsaref.h"
#include 	<md5.h>

#define		KEYDATABASE "DB.key"	

void display(char * Message)
{
        printf("%-20s:%-50s\n","Key Server",Message);
}

int keyServerValidator(char * Id,char * Key)
{
	FILE *fptr;
	char IdKeyEntry[2][SIZE];
	memset(Key,'\0',SIZE);
	display(constructMessage("Validating %s",Id));
	fptr=fopen(KEYDATABASE,"r");
	if(fptr==NULL) return errorMessage("Cannot open key database");
	while(fgets((char*)IdKeyEntry,(SIZE*2)+1,fptr)!=NULL)
	{
		if(!memcmp(Id,IdKeyEntry[0],SIZE)) 
		{
			memcpy(Key,IdKeyEntry[1],SIZE);
			break;
		}
	}
	if(!strlen(addEndOfString(Key,SIZE))) return errorMessage(constructMessage("ID %s invalid",Id));
	display("Validation successful");
	display(constructMessage("Secret key is %s",addEndOfString(Key,SIZE)));
	fclose(fptr);
	return 0;
}

void randKey(char * KCS)
{
	FILE *dt, *popen();
	unsigned char text[128], randText[128];
	dt = popen("date; ps -e", "r");
	fread(text, 128, 1, dt);
	md5_calc(randText, text, 128);
	memcpy(KCS, randText, 8);
	pclose(dt);
}

int keyGenerator(char * KCS)
{
	randKey(KCS);
	if(!strlen(addEndOfString(KCS,SIZE))) return errorMessage("Cannot generate Key");
	display("Session key KCS created");
	printEncrypted("Session key KCS",KCS,SIZE);
	return 0;
}

int encryptKeyToken(EncKeyTokenStruct * EncToken,KeyTokenStruct Token,char * Key)
{
	char InitVector[8];
	memset(InitVector,'\0',8);
	display(constructMessage("Encrypting Token with key %s",Key));
 	R_EncryptPEMBlock(EncToken->Message,&(EncToken->Length),(unsigned char*) &Token,sizeof(Token),Key,InitVector);
	if(EncToken->Length==0) return errorMessage("Cannot Encrypt Token");
	display("Token Encrypted");
	printEncrypted("Encrypted Token",EncToken->Message,EncToken->Length);
	return 0;
}

int tokenBuilder(EncKeyTokenStruct * EncToken,KeyRequestStruct KeyReq,char * KCS,char * Key)
{
	KeyTokenStruct Token;
	if(copyText(Token.C,SIZE,KeyReq.Content.C,SIZE)) return errorMessage("Cannot create Token");
	if(copyText(Token.S,SIZE,KeyReq.Content.S,SIZE)) return errorMessage("Cannot create Token");
	if(copyText(Token.Key,SIZE,KCS,SIZE)) return errorMessage("Cannot create Token");
	display("Token created");
	printToken(Token);
	if(encryptKeyToken(EncToken,Token,Key)) return errorMessage("Token created but not encrypted");
	return 0;
}

int encryptKeyReply(EncKeyReplyStruct * EncKeyReply,KeyReplyStruct KeyReply, char * Key)
{
	char InitVector[8];
        memset(InitVector,'\0',8);	
	display(constructMessage("Encrypting Reply with Key %s",Key));
	R_EncryptPEMBlock(EncKeyReply->Message,&(EncKeyReply->Length),(unsigned char*) &KeyReply, sizeof(KeyReply),Key,InitVector);
	if(EncKeyReply->Length==0) return errorMessage("Cannot Encrypt Reply");
	display("Reply Encrypted");
	printEncrypted("Encrypted Reply",EncKeyReply->Message,EncKeyReply->Length);
	return 0;
}

int replyBuilder(KeyRequestStruct KeyReq,char * KCS, EncKeyReplyStruct* EncReply, char * KeyC, char * KeyS)
{
	KeyReplyStruct Reply;
	if(copyText(Reply.Content.C,SIZE,KeyReq.Content.C,SIZE)) return errorMessage("Cannot create Reply");	
	if(copyText(Reply.Content.S,SIZE,KeyReq.Content.S,SIZE)) return errorMessage("Cannot create Reply");	
	if(copyText(Reply.Content.Key,SIZE,KCS,SIZE)) return errorMessage("Cannot create Reply");
	if(tokenBuilder(&(Reply.Content.Token),KeyReq,KCS,KeyS)) return errorMessage("Cannot create Reply");
	Reply.Length=strlen(addEndOfString(Reply.Content.C,SIZE))+strlen(addEndOfString(Reply.Content.S,SIZE))+strlen(addEndOfString(Reply.Content.Key,SIZE))+Reply.Content.Token.Length;
	display("Reply built");
	printKeyReply(Reply);
	if(encryptKeyReply(EncReply,Reply,KeyC)) return errorMessage("Reply built but not encrypted");
	return 0;
}

EncKeyReplyStruct * reqskey_1(KeyRequestStruct KeyReq)
{
	unsigned char KCS[SIZE],KeyC[SIZE],KeyS[SIZE];
	static EncKeyReplyStruct Reply;
	display("Request recieved");
	printKeyRequest(KeyReq);
	if(keyServerValidator(addEndOfString(KeyReq.Content.C,SIZE),KeyC)) Reply.Length=-1;
	else if(keyServerValidator(KeyReq.Content.S,KeyS)) Reply.Length=-1;
	else if(keyGenerator(KCS)) Reply.Length-1;
	else if(replyBuilder(KeyReq,addEndOfString(KCS,SIZE),&Reply,addEndOfString(KeyC,SIZE),addEndOfString(KeyS,SIZE))) Reply.Length=-1;
	else display("Request Completed");
	return &Reply;
}
