//Implemented by Rishabh Choudhary
#include        <rpc/rpc.h>     /* standard RPC include file */
#include        "C2S.h"
#include 	<stdio.h>
#include 	<stdlib.h>
#include	<string.h>
#include	"ClientServer.h"
#include	"ClientAppServer.h"
#include	"Skey.h"
#include	"global.h"
#include	"rsaref.h"

void display(char * Message)
{
        printf("%-20s:%-50s\n","App Server",Message);
}

int decryptEncReqToken(EncReqTokenStruct EncToken, ReqTokenStruct * Token)
{
	unsigned int DecTokenLength=0;
	char DecTokenString[ENCTOKENSIZE];
	char InitVector[8];
	memset(InitVector,'\0',8);
	printEncrypted("Encrypted Token",EncToken.Message,EncToken.Length);
	display(constructMessage("Decrypting Token with key %s",key));
        R_DecryptPEMBlock(DecTokenString, &DecTokenLength, EncToken.Message,EncToken.Length,key,InitVector);
        if(DecTokenLength==0) return errorMessage("Cannot decrypt Token");
        memcpy((unsigned char*) Token,DecTokenString,DecTokenLength);
        display("Token decrypted");
        printReqToken(*Token);
        return 0;
}	

int AppServerValidator(RequestStruct Request,ReqTokenStruct * Token)
{
	if(decryptEncReqToken(Request.Content.Token,Token)) return errorMessage("Cannot read Token");
	display("Session key KCS obtained");
	printEncrypted("Session key KCS",Token->Key,SIZE);
	if(strcmp(addEndOfString(Request.Content.C,SIZE),addEndOfString(Token->C,SIZE))) return errorMessage(constructMessage("Client %s invalid",Request.Content.C)); 
	display(constructMessage("Client %s valid",addEndOfString(Request.Content.C,SIZE)));
	display("Validation successful");
	return 0;
}

int encryptReply(ReplyStruct Reply,char * KCS,EncReplyStruct * EncReply)
{
	char InitVector[8];
	memset(InitVector,'\0',8);
	display("Encrypting Reply with Session key KCS");
	printEncrypted("Session key KCS",KCS,SIZE);
        R_EncryptPEMBlock(EncReply->Message,&(EncReply->Length),(unsigned char*) &Reply,sizeof(Reply),KCS,InitVector);
        if(EncReply->Length==0) return errorMessage("Cannot Encrypt Reply");
        display("Reply Encrypted");
        printEncrypted("Encrypted Reply",EncReply->Message,EncReply->Length);
        return 0;
}

int replyBuilder(ReqTokenStruct Token,char * String,EncReplyStruct * EncReply)
{
	ReplyStruct Reply;
	if(copyText(Reply.Content.C,SIZE,Token.C,SIZE)) return errorMessage("Cannot create Reply");	
	if(copyText(Reply.Content.S,SIZE,Token.S,SIZE)) return errorMessage("Cannot create Reply");	
	if(copyText(Reply.Content.Output.String,ARGSIZE,String,strlen(String))) return errorMessage("Cannot create Reply");
	Reply.Content.Output.Length=strlen(addEndOfString(Reply.Content.Output.String,ARGSIZE));
	Reply.Length=strlen(addEndOfString(Reply.Content.C,SIZE))+strlen(addEndOfString(Reply.Content.S,SIZE))+Reply.Content.Output.Length;
	display("Reply built");	
	printReply(Reply);
	if(encryptReply(Reply,addEndOfString(Token.Key,SIZE),EncReply)) return errorMessage("Reply built but not encrypted");
	return 0;
}

int decryptArgument(EncMsgStruct EncArgument,char * KCS,MsgStruct * Argument)
{
	unsigned int DecArgumentLength=0;
	char DecArgumentString[ENCMSGSIZE];
	char InitVector[8];
	memset(InitVector,'\0',8);
	printEncrypted("Encrypted Argument",EncArgument.Message,EncArgument.Length);
      	display("Decrypting Argument with Session key KCS");
	printEncrypted("Session key KCS",KCS,SIZE); 
	R_DecryptPEMBlock(DecArgumentString, &DecArgumentLength, EncArgument.Message,EncArgument.Length,KCS,InitVector);
        if(DecArgumentLength==0) return errorMessage("Cannot decrypt Argument");
        memcpy((unsigned char*) Argument,DecArgumentString,DecArgumentLength);
        display("Argument decrypted");
        printArgument(*Argument);
        return 0;
}	

int findAlphabet(unsigned char ** String,unsigned char * ArgumentString)
{
	int i=0,j=0;
	*String=(char*)malloc((strlen(ArgumentString)+1)*sizeof(char));
	if(*String==NULL) return errorMessage("Cannot create output string");
	memset(*String,'\0',strlen(ArgumentString)+1);
	while(i<strlen(ArgumentString))
	{
		if((ArgumentString[i]>=65&&ArgumentString[i]<=90)||(ArgumentString[i]>=97&&ArgumentString[i]<=122))
			(*String)[j++]=ArgumentString[i];
		i++;	
	}
	return 0;
}	

EncReplyStruct * alpha_1(RequestStruct Request)
{
	unsigned char * String;
	static EncReplyStruct Reply;
	MsgStruct Argument;
	ReqTokenStruct * Token;	
	display("Service to find alphabets called");
	printRequest(Request);
	if(AppServerValidator(Request,Token)) Reply.Length=-1;
	else if(decryptArgument(Request.Content.Argument,addEndOfString(Token->Key,SIZE),&Argument)) Reply.Length=-1; 
	else if(findAlphabet(&String,addEndOfString(Argument.String,ARGSIZE))) Reply.Length=-1;
	else if(replyBuilder(*Token,addEndOfString(String,ARGSIZE),&Reply)) Reply.Length=-1;
	else display("Request Completed");
	free(Token);
	return &Reply;
}

int findNumeric(unsigned char ** String,unsigned char * ArgumentString)
{
        int i=0,j=0;
        *String=(char*)malloc((strlen(ArgumentString)+1)*sizeof(char));
        if(*String==NULL) return errorMessage("Cannot create output string");
        memset(*String,'\0',strlen(ArgumentString)+1);
        while(i<strlen(ArgumentString))
        {
		if(ArgumentString[i]>=48&&ArgumentString[i]<=57)
                        (*String)[j++]=ArgumentString[i];
                i++;
        }
        return 0;
}

EncReplyStruct * numeric_1(RequestStruct Request)
{
	unsigned char * String;
	static EncReplyStruct Reply;
	MsgStruct Argument;
	ReqTokenStruct * Token;	
	display("Service to find numbers called");
	printRequest(Request);
	if(AppServerValidator(Request,Token)) Reply.Length=-1;
	else if(decryptArgument(Request.Content.Argument,addEndOfString(Token->Key,SIZE),&Argument)) Reply.Length=-1;
	else if(findNumeric(&String,addEndOfString(Argument.String,ARGSIZE))) Reply.Length=-1;
	else if(replyBuilder(*Token,addEndOfString(String,ARGSIZE),&Reply)) Reply.Length=-1;
	else display("Request Completed");
	free(Token);
	return &Reply;
}
