//Implemented by Rishabh Choudhary
#include        <stdio.h>
#include        <rpc/rpc.h> 
#include        "C1K.h"
#include	<stdlib.h>
#include	<string.h>
#include	"ClientServer.h"
#include	"ClientKeyServer.h"

char * display(char * Message)
{
        char * DisplayBuffer;
        DisplayBuffer=(char*)malloc(1050*sizeof(char));
        memset(DisplayBuffer,'\0',1050);
        sprintf(DisplayBuffer,"%-20s:%-50s\n","Client",Message);
        printf(DisplayBuffer);
        return DisplayBuffer;
}

int createKeyServerConn(CLIENT ** ClientConn,char * Server)
{
	 if ((*ClientConn = clnt_create(Server, CK_PROG, CK_VERS, "udp"))
 == NULL)
        {
                clnt_pcreateerror(constructMessage("%-20s","Client"));
                return errorMessage("Cannot create connection");
        }
	display("Connection created");
	return 0;
}

int keyRequestBuilder(KeyRequestStruct * KeyRequest,char * C,char * S)
{
	if(copyText(KeyRequest->Content.C,SIZE,C,strlen(C)))
return errorMessage("Cannot copy C to request");
        if(copyText(KeyRequest->Content.S,SIZE,S,strlen(S)))
return errorMessage("Cannot copy S to request");
        KeyRequest->Length=strlen(addEndOfString(KeyRequest->Content.C,SIZE))+strlen(addEndOfString(KeyRequest->Content.S,SIZE));
	return 0;
}
	
int getKey(CLIENT * ClientKeyServerConn,char * C, char * S, KeyReplyStruct ** KeyReply)
{
        KeyRequestStruct KeyRequest;
	if(keyRequestBuilder(&KeyRequest,C,S)) return errorMessage("Cannot create request");
	printKeyRequest(KeyRequest);
        if((*KeyReply=reqskey_1(KeyRequest,ClientKeyServerConn))==NULL)
        {
                clnt_perror(ClientKeyServerConn, constructMessage("%-20s","Client"));
                return errorMessage("Call failed");
        }
        display("Reply Received");
        printKeyReply(**KeyReply);
	if((*KeyReply)->Length==-1) return errorMessage("Bad reply");
	return 0;	
}

int main(int argc,char * argv[])
{
	KeyReplyStruct * KeyReply;	
	CLIENT *ClientKeyServerConn;
	if(createKeyServerConn(&ClientKeyServerConn,argv[3])) return errorMessage("Connection failed");	
	if(getKey(ClientKeyServerConn,argv[1],argv[2],&KeyReply)) return errorMessage("Cannot get key");	
	clnt_destroy(ClientKeyServerConn);
	return 0;
	 
}
