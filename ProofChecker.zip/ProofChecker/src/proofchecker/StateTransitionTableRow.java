/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofchecker;

/**
 *
 * @author Rishabh
 */
public class StateTransitionTableRow {
    int PresentState;
    String Symbols;
    int NextState;

    public StateTransitionTableRow(int PresentState, String Symbols, int NextState) {
        this.PresentState = PresentState;
        this.Symbols = Symbols;
        this.NextState = NextState;
    }

    public StateTransitionTableRow() {
    }

    
}
