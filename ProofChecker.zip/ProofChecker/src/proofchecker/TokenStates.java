/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofchecker;

import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author Rishabh
 */
public class TokenStates {
    final static int Empty=0;
    final static int Paren=1;
    final static int Num=2;
    final static int PartString=3;
    final static int CompString=4;
    
    final static String LParen="(";
    final static String RParen=")";
    final static String Digits="0123456789";
    final static String Space=" ";
    final static String DQuote="\"";
    final static String All="";
    final static String None=null;
    
    final static ArrayList<Integer> InvalidStates=new ArrayList<Integer>();
    final static ArrayList<String> AcceptableSymbols=new ArrayList<String>();
    final static ArrayList<StateTransitionTableRow> StateTransitionTable=new ArrayList<StateTransitionTableRow>();
    
    static {
        InvalidStates.add(Empty);
        InvalidStates.add(PartString);
        AcceptableSymbols.add(Empty,Space+LParen+RParen+Digits+Space+DQuote);
        AcceptableSymbols.add(Paren,None);
        AcceptableSymbols.add(Num,Digits);
        AcceptableSymbols.add(PartString,All);
        AcceptableSymbols.add(CompString,None);
        StateTransitionTable.add(new StateTransitionTableRow(Empty, LParen+RParen, Paren));
        StateTransitionTable.add(new StateTransitionTableRow(Empty, Digits, Num));
        StateTransitionTable.add(new StateTransitionTableRow(Empty, DQuote, PartString));
        StateTransitionTable.add(new StateTransitionTableRow(PartString, DQuote, CompString));
    }
}
