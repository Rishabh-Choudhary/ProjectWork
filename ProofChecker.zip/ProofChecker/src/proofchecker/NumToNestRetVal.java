/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofchecker;

import java.util.ArrayList;

/**
 *
 * @author Rishabh
 */
public class NumToNestRetVal {
    public int linesRead;
    public ArrayList<Integer> innerNested;

    public NumToNestRetVal(int linesRead, ArrayList<Integer> innerNested) {
        this.linesRead = linesRead;
        this.innerNested = innerNested;
    }
    
}
