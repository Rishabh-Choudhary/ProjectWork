/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofchecker;

import java.util.ArrayList;

/**
 *
 * @author Rishabh
 */
public class Tokenizer {

    private static String S;
   /*
munch(S):
chars := [],
state := 'empty',
while S is not empty and canPush(head(S),state):
remove the first character of S and add it to the \
end of chars,
state := newState(state,c)
if validToken(state): return (charsToTok(chars), True))
else: return(None,False)
If S is a list of characters, tokenize(S) is the list of tokens
resulting from tokenizing S using a greedy maximal munch.
*/
  
    private static boolean canPush(CharSequence C,int State)
    {
      if(TokenStates.AcceptableSymbols.get(State)!=null 
              && (TokenStates.AcceptableSymbols.get(State).contains(C) 
                    || TokenStates.AcceptableSymbols.get(State).length()==0))
          return true;
      else
          return false;
    }
    
    private static int newState(int State,CharSequence C)
    {
        StateTransitionTableRow STRow;
        int i=TokenStates.StateTransitionTable.size()-1;
        while(i>=0)
        {
            STRow=TokenStates.StateTransitionTable.get(i);
            if(STRow.PresentState==State && STRow.Symbols.contains(C))
                return STRow.NextState;
            i--;
        }
        return State;
    }
    
    private static boolean validState(int State)
    {
        if(TokenStates.InvalidStates.contains(State))
            return false;
        else
            return true;
    }
    
    private static String munch(){
        String Chars=new String();
        int PresentState=TokenStates.Empty;
        while (S.length()>0 && canPush(S.subSequence(0, 1),PresentState))
        {
            PresentState=newState(PresentState,S.subSequence(0, 1));
            if(PresentState!=TokenStates.Empty)
                Chars=Chars.concat(S.substring(0, 1));
            S=S.substring(1);
        }
        if(validState(PresentState))
            return Chars;
        else
            return null;
    }
    
    /*
tokens(S):
tokens = []
remove all initial white space from S,
while S is not empty
remove all initial white space from S,
(token,Flag) := munch(S)
if Flag:
tokens := tokens + [token]
else
return (tokens,True)
return (None,False)
*/

    public static ArrayList<String> getTokens(String Sin)
    {
        String Token;
        S=Sin;
        ArrayList<String> Tokens=new ArrayList<String>();
        while(S.length()>0)
        {
            Token=munch();
            if(Token!=null)
                Tokens.add(Token);
        }
        return Tokens;
    }
}

