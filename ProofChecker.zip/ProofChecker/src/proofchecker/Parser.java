/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofchecker;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Rishabh
 */
public class Parser {
/*
parseTheorem(L):
s := L[2]
A := parseArgument(L[3:len(L)­1])
return ["t", s, A]
*/
    /*
parse(e):
if isTheorem(e) : return parseTheorem(e)
if isAssertion(e) : return parseAssertion(e)
if isSupposition(e): return e
*/
    /*
parseAssertion(e):
s := e[2]
J := parseJustification(e[3:len(e)­1])
return ("a", s, J)
*/
    
public static ArrayList<Object> parseTheoremAssertion(String Type, String Statement, List<Object> Argument) {
        ArrayList<Object> ParsedObject=new ArrayList<>();
        ParsedObject.add(Type);
        ParsedObject.add(Statement);
        ParsedObject.add(Argument);
        return ParsedObject;
}
    
public static boolean isSupposition(Object argument)
{
    return argument.toString().toLowerCase().startsWith("\"suppose");
}

public static boolean isTheorem(Object argument)
{
    return argument.toString().equals("\"t\"");
}

public static boolean isAssertion(Object argument)
{
    return argument.toString().equals("\"a\"");
}

public static Object parse(List L)
{
    if(L.size()>1)
    {
        if(isTheorem(L.get(1)))
            return parseTheoremAssertion(L.get(1).toString(),L.get(2).toString(),parseArgument(L.subList(3, L.size()-1)));
        if(isAssertion(L.get(1)))
            return parseTheoremAssertion(L.get(1).toString(),L.get(2).toString(),parseJustification(L.subList(3, L.size()-1)));
    }
    else
        if(L.size()==1)
            if(isSupposition(L.get(0))) 
                return L.get(0);
    return new Object();
}
    
    /*
parseArgument(L)
A,i := [], 1
while L[i] != RPAREN:
A := A+[parse(L[i:nextExp(i)])]
i := extExp(L,i)
return A
*/

private static int nextExp(List<String> L, int i)
{
    if(L.get(i).equals(TokenStates.LParen))
    {
        int iterator=1;
        while(iterator>0)
        {
            i++;
            if(L.get(i).equals(TokenStates.LParen))
                iterator++;
            if(L.get(i).equals(TokenStates.RParen))
                iterator--;
        }
    }
    return i+1;
}

private static List<Object> parseArgument(List<String> L)
{
    ArrayList<Object> ParsedArgument=new ArrayList<>();
    int i=1;
    while(i<L.size() && !L.get(i).equals(TokenStates.RParen))
    {
        int NextExpIndex=nextExp(L,i);
        ParsedArgument.add(parse(L.subList(i,NextExpIndex)));
        i=NextExpIndex;
    }
    return ParsedArgument;
}
    /*
parseJustification(L): return L[1:len(L)­1]
*/
private static List<Integer> parseJustification(List<String> L)
{
    ArrayList<Integer> ParsedJustification=new ArrayList<>();
    L= L.subList(1, L.size()-1);
    for (String Reason : L)
    {
        ParsedJustification.add(Integer.parseInt(Reason));
    }
    return ParsedJustification;
}

/*
argLength(A):
L=0
for e in A:
L=L+componentLength(A)
return L

componentLength(e):
if isSupposition(e): return 1
if assertion(e): return 1
if theorem(e): return argLength(e[1])+1
*/

public static int argLength(List<Object> Arguments)
{
    int Length=0;
    for(Object Argument:Arguments)
    {
        Length+=componentLength(Argument);
    }
    return Length;
}

public static int componentLength(Object Argument)
{
    try
    {
    if(isSupposition(Argument)) return 1;
    else
    {
        if(isTheorem(((List)Argument).get(0))) return argLength((List)((List)Argument).get(2))+1;
        if(isAssertion(((List)Argument).get(0))) return 1;
    }
    }
    catch(Exception ex)
    {
        return 0;
    }
    return 0;
}


public static NumToNestRetVal numberToNested(List<Object> Arguments, int n)
{
    ArrayList<Integer> nested=new ArrayList<>();
    int index=0;
        while(n>0 && index<Arguments.size())
        {
            if(isSupposition(Arguments.get(index))) 
            {
                n--;
                if(n==0) 
                    nested.add(index);
                index++;
            }
            else
            {
                if(isAssertion(((List)Arguments.get(index)).get(0)))
                {
                    n--;
                    if(n==0) 
                        nested.add(index);
                    index++;
                }
                else
                {
                    if(isTheorem(((List)Arguments.get(index)).get(0)))
                    {
                        n--;
                        if(n==0) 
                        {
                            nested.add(index);
                            nested.add(1);
                        }
                        if(n>0) 
                        {
                            NumToNestRetVal rv=numberToNested((List)((List)Arguments.get(index)).get(2), n);
                            int sum=0;
                            if(!rv.innerNested.isEmpty())
                            {
                                nested.add(index);
                                nested.add(2);
                            }
                            for(Integer in: rv.innerNested)
                                nested.add(in);
                            n=rv.linesRead;
                        }
                        index++;
                    }
                }
            }
        }
        return (n==0)?new NumToNestRetVal(n, nested):new NumToNestRetVal(n, new ArrayList<Integer>());
}

/*
indexNested(A,N):
  if N ==[k], return A[k]
  front = N[0:len(N)­1]
  back= N[len(N)­1]
  return indexNested(A,front) [back]
*/

public static Object indexNested(List<Object> argument, List<Integer> numToNested)
{
    if(numToNested.isEmpty())
        return argument;
    else 
        return ((List<Object>)indexNested(argument,numToNested.subList(0, numToNested.size()-1))).get(numToNested.get(numToNested.size()-1));
}

/*
index(A,n):
  return indexNested(A,numberToNested(A,n))
*/

public static Object index(List<Object> argument, int n)
{
    return indexNested(argument,numberToNested(argument,n).innerNested);
}

/*

Justifications(A,n):
   line = index(A,n)
   if line is not an assertion, return [ ]
   if line is an assertion, return the number of integers in line[1]
*/

public static List<Integer> justifications(List<Object> argument, int n)
{
    try{
        Object line=index(argument,n);
        if(!isSupposition(line))
            if(isAssertion(((List)line).get(0)))
                return (List)((List)line).get(2);
        return new ArrayList<Integer>();
    }
    catch(Exception ex)
    {
         return new ArrayList<Integer>();
    }
}

/*
suppositionsOf(A):
  L = [ ]
  for i in range(0,arglength(A)):
    if A[i] is a supposition:
      L=L+[i]
*/


public static ArrayList<Integer> suppositionsOf(List<Object> argument,int base)
{
    ArrayList<Integer> suppositions=new ArrayList();
    for(int i=0;i<argument.size();i++)
        if(isSupposition(argument.get(i)))
            suppositions.add(base+i+1);
    return suppositions;
}

/*

suppositionsInForce(A,n):
  N = numberToNested(A,n)
  Ms = initSegs(N)  # the proper initial segments of N
  L=[ ]
  for M in Ms:
       L=L+suppositionsOf(M)
*/

public static ArrayList<String> suppositionsInForce(List<Object> argument,int n)
{
    ArrayList<String> suppositions=new ArrayList<>();
    ArrayList<Object> tempArg=new ArrayList<>(argument);
    ArrayList<Integer> numToNested=numberToNested(tempArg,n).innerNested;
    int i,j;
    for(i=0;i<numToNested.size()-1;i++)
    {
        int range=numToNested.get(i);
        for(j=0;j<range;j++)
            if(isSupposition(tempArg.get(j)))
                suppositions.add(tempArg.get(j).toString());
        tempArg=(ArrayList<Object>)indexNested(argument,numToNested.subList(0,i+1));
    }
    for(j=0;j<numToNested.get(i);j++)
        if(isSupposition(tempArg.get(j)))
                suppositions.add(tempArg.get(j).toString());
    return suppositions;
}


public static boolean isValid(List<Object> Theorem)
{
    int n,argLength=argLength((List)Theorem.get(2));
    for(n=1;n<=argLength;n++)
    {
        List<String> suppositionsN=suppositionsInForce((List)Theorem.get(2), n);
        List<Integer> justifications=justifications((List)Theorem.get(2), n);
        if(!justifications.isEmpty())
            for(Integer m:justifications)
            {
                if(m>=n) return false;
                List<String> suppositionsM=suppositionsInForce((List)Theorem.get(2), m);
                if(!suppositionsN.containsAll(suppositionsM))
                    return false;
            }
    }
    return true;
}

public static String conjunctionOf(List<Object> argument,List<Integer> X)
{
    String conjunction=new String("");
    for(Integer x:X)
    {
        try{
            conjunction=conjunction.concat(((List)index(argument,x)).get(1)+" & ");
        }
        catch(Exception ex)
        {
            conjunction=conjunction.concat(index(argument,x)+" & ");
        }
    }
    return conjunction.length()==0?conjunction:"( "+(conjunction.substring(0, conjunction.length()-3<0?conjunction.length():conjunction.length()-3))+" ) => ";
}

public static String getLastLine(List<Object> argument)
{
   return ((List)(argument.get(argument.size()-1))).get(1).toString();
}

public static String getPremise(List<Object> argument,int n)
{
    Object line=index(argument,n);
    try
    {
        if(!isSupposition(line))
            if(isAssertion(((List)line).get(0)))
                return conjunctionOf(argument,(List)((List)line).get(2))+((List)line).get(1)+" [Line "+(n)+"]";
    }
    catch(Exception ex)
    {
        List<Integer> innerArgument=numberToNested(argument, n+1).innerNested;
        return "( "+conjunctionOf(argument,suppositionsOf((List)indexNested(argument,innerArgument.subList(0,innerArgument.size()-1)),n))+getLastLine((List)indexNested(argument,innerArgument.subList(0,innerArgument.size()-1)))+" ) => "+line+" [Line "+(n)+"]";
    }
    return "";
}

public static List<String> generatePremises(List<Object> Theorem)
{
    ArrayList<String> Premises=new ArrayList<>();
    for(int i=1;i<=argLength((List)Theorem.get(2));i++)
        Premises.add(getPremise((List)Theorem.get(2), i));
    Premises.add("( "+conjunctionOf((List)Theorem.get(2), suppositionsOf((List)Theorem.get(2),0))+getLastLine((List)Theorem.get(2))+" ) => "+Theorem.get(1)+" [Overall Theorem]");
    return Premises;
}

}
